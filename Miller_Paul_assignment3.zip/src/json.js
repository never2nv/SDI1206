/*
 * 
 */



var json = {
	"friends": [
		{
			"name": "Sandra Detamore",
			"age": 43
		},
		{
			"name": "Carol Lewis",
			"age": 39
		},
		{
			"name": "Frank Lewis",
			"age": 41
		},
		{
			"name": "Stan Greathouse",
			"age": 35
		}
	
	]
};











































/*
 * TUTORIAL JSON

var json = {
	"friends": 
	{
		"1": 
		{
			"name": "Carol Lewis",
			"age": 39
		},
		"2": 
		{
			"name": "Frank Lewis",
			"age": 41
		},
		"3": 
		{
			"name": "Sandra Detamore",
			"age": 43
		},
		"4": 
		{
			"name": "Stan Greathouse",
			"age": 35
		},
	}
};

for (var key in json.friends) 
{
	var friend = json.friends[key];
	//friend.name
};
*/






