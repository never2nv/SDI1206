/*Author: Paul J. Miller
Date: 05-17-2012
Deliverable 3 - SDI 1205
Sci-fi Voyage.
*/

// alert("JSON WORKS!");

// JSON EXAMPLE

/*
for (var key in json.captains) {
	var captains = jason.captains[key]
	captains.name
}
*/


var json2 = {
	
	"captains": [
		{
			"uuid" : "001",
			"name" : "Paul Miller",
			"age"  : "26"
		},
		
		{
			"uuid": "002",
			"name": "Richard Sidney",
			"age" : "32"
		},
		
		{
			"uuid": "003",
			"name": "Micheal Crusher",
			"age" : "29"
		},
		
		{
			"uuid": "004",
			"name": "Donald Riker",
			"age" : "33"
		},
		
		{
			"uuid": "005",
			"name": "Frank Adams",
			"age" : "29"
		},
		
		{
			"uuid": "006",
			"name": "Max Shepard",
			"age" : "29"
		},
		
		{
			"uuid": "007",
			"name": "Kyle Winston",
			"age" : "29"
		},
		
		{
			"uuid": "008",
			"name": "Roger Williams",
			"age" : "29"
		},
	]
};



